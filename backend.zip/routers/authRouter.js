const router = require("express").Router();
const { Users } = require("../models/models");
const { upload } = require("../middleware/multer");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

// multer 

// const path = require("path")

// const multer = require("multer")

// var storage = multer.diskStorage({
//     destination: ((req, file, cb) => {
//         cb(null, 'uploads/')
//     }),
//     filename: ((req, file, cb) => {
//         let ext = path.extname(file.originalname)
//         cb(null, Date.now() + ext)
//     })
// });

// var upload = multer({
//     storage: storage,
//     fileFilter: ((req, file, callback) => {
//         if (file.mimetype === "image/png"
//             || file.mimetype === "image/jpg"
//             || file.mimetype === "image/jpeg") {
//             callback(null, true);
//         } else {
//             console.log("Only jpg & png files supported...!");
//             callback(null, false);
//         }
//     }),
//     limits: {
//         fileSize: 1024 * 1024 * 5
//     }
// });

// register

router.post("/signup", upload.single("img"), async (req, res) => {
    // console.log(req.body.img);
    // console.log(req.body.uname)
    // console.log(req.file);

    // console.log(req.body);


    // res.send("done");
    if (req.file) req.body.img = req.file.filename;
    try {
        // validation
        const existingUser = await Users.findOne({ mail: req.body.mail });
        if (existingUser)
            return res.status(400).json({
                errorMessage: "An account with this email already exists.",
            });

        // hash the password

        const salt = await bcrypt.genSalt();
        const passwordHash = await bcrypt.hash(req.body.pass, salt);
        req.body.pass = passwordHash;
        // save a new user account to the db

        const newUser = new Users(req.body);
        const savedUser = await newUser.save();

        // sign the token
        const token = jwt.sign({ user: savedUser._id }, process.env.JWT_SECRET);

        // send the token in a HTTP-only cookie

        res.cookie("token", token, {
            httpOnly: true,
            secure: true,
            sameSite: "none",
        }).send();
    } catch (err) {
        console.error(err);
        res.status(500).send();
    }
});

// log in

router.post("/login", async (req, res) => {
    try {
        const { mail, pass } = req.body;
        const existingUser = await Users.findOne({ mail: mail });
        if (!existingUser)
            return res.status(401).json({ errorMessage: "Wrong mail or password." });
        const passwordCorrect = await bcrypt.compare(
            pass,
            existingUser.pass
        );
        if (!passwordCorrect)
            return res.status(401).json({ errorMessage: "Wrong username or password." });

        // sign the token

        const token = jwt.sign(
            {
                user: existingUser._id,
            },
            process.env.JWT_SECRET
        );

        // send the token in a HTTP-only cookie

        res
            .cookie("token", token, {
                httpOnly: true,
                secure: true,
                sameSite: "none",
            })
            .send();
    } catch (err) {
        console.error(err);
        res.status(500).send();
    }
});

router.get("/logout", (req, res) => {
    res
        .cookie("token", "", {
            httpOnly: true,
            secure: true,
            sameSite: "none",
        })
        .send();
    console.log("Logged Out")
});

router.get("/loggedIn", async (req, res) => {
    try {
        const token = req.cookies.token;
        if (!token) return res.json({ auth: false });
        const verified = jwt.verify(token, process.env.JWT_SECRET);
        const user = await Users.findOne({ _id: verified.user }, { pass: 0, __v: 0 }).populate('blogs').populate("followers", "-pass -__v").populate("following", "-pass -__v");
        if (user == null || user == undefined) throw e;
        res.send({ auth: true, user });
    } catch (err) {
        console.log(err);
        res.json({ auth: false });
    }
});

module.exports = router;
