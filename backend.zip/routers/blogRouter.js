const router = require("express").Router();
const auth = require("../middleware/auth");
const { Users, Blogs } = require("../models/models");

const temp = {
    "a":1,
    b:1
}

router.get("/all", async (req, res) => {
    try {
        const blogs = await Blogs.find().populate('author', '-v -pass -blogs -__id');
        res.send(blogs);
    } catch (e) {
        console.log(e);
        res.status(500).send();
    }
})

router.get("/:id", async (req, res) => {
    try {
        const blog = await Blogs.findOne({ _id: req.params.id }).populate('author', '-v -pass -blogs -__id');
        res.send(blog);
    } catch (e) {
        console.log(e);
        res.status(500).send();
    }
})

router.post("/", auth, async (req, res) => {
    try {
        req.body.author = req.user;
        const newBlog = new Blogs(req.body);
        const savedBlog = await newBlog.save();
        await Users.updateOne(
            { _id: req.user },
            { $push: { blogs: { _id: savedBlog._id } } }
        );
        res.send("Blog Saved");
    } catch (err) {
        console.error(err);
        res.status(500).send();
    }
});

router.put("/:id", auth, async (req, res) => {
    try {
        await Blogs.updateOne(
            { _id: req.params.id },
            { $set: req.body }
        );
        res.send("Blog updated");
    } catch (err) {
        console.error(err);
        res.status(500).send();
    }
})

router.delete("/:id", auth, async (req, res) => {
    try {
        await Blogs.deleteOne({ _id: req.params.id });
        await Users.updateOne({ _id: req.user }, {
            $pullAll: {
                blogs: [{
                    _id: req.params.id
                }]
            }
        });
        res.send("Blog Deleted");
    } catch (e) {
        console.log(e);
        res.status(500).send();
    }
})

// router.post("/:handle", auth, async (req, res) => {
//     try {
//         const filter = req.params.handle == "bank" ? {} : { password: 0, requests: 0, donations: 0, stock: 0, __v: 0 };
//         const banks = await BloodBank.find(req.body, filter);
//         res.json(banks);
//     } catch (err) {
//         console.error(err);
//         res.status(500).send();
//     }
// });

// router.get("/allBanks/:state/:district", async (req, res) => {
//     try {
//         const banks = await BloodBank.find({ state: req.params.state, district: req.params.district }, { password: 0, _id: 0, donations: 0, requests: 0, stock: 0 });
//         res.json(banks);
//     } catch (err) {
//         console.error(err);
//         res.status(500).send();
//     }
// });

// router.put("/updateStock", auth, async (req, res) => {
//     try {
//         const prevStock = await BloodBank.findOne({ _id: req.user }, { stock: 1 });
//         await BloodBank.updateOne(
//             { _id: req.user },
//             { $set: { ["stock." + req.body.bloodGroup]: prevStock.stock[req.body.bloodGroup] + req.body.units } }
//         )
//         res.status(200).send();
//     } catch (err) {
//         console.error(err);
//         res.status(500).send();
//     }
// });

// router.put("/deleteStock", auth, async (req, res) => {
//     try {
//         const prevStock = await BloodBank.findOne({ _id: req.user }, { stock: 1 });
//         if (prevStock.stock[req.body.bloodGroup] < req.body.units) {
//             res.status(404).send("Not enough blood");
//         } else {
//             await BloodBank.updateOne(
//                 { _id: req.user },
//                 { $set: { ["stock." + req.body.bloodGroup]: prevStock.stock[req.body.bloodGroup] - req.body.units } }
//             )
//             res.status(200).send();
//         }
//     } catch (err) {
//         console.error(err);
//         res.status(500).send();
//     }
// });

// router.get("/getStock", auth, async (req, res) => {
//     try {
//         const data = await BloodBank.findOne(
//             { _id: req.user },
//             { _id: 0, stock: 1 }
//         )
//         res.status(200).send(data);
//     } catch (err) {
//         console.error(err);
//         res.status(500).send();
//     }
// });

// router.put("/donations", auth, async (req, res) => {
//     try {
//         Donations.updateOne({ _id: req.body.id }, { status: req.body.status }, (err, user) => {
//             if (err) {
//                 res.status(404).send("Donation not found");
//             } else {
//                 res.status(200).send("Status updated");
//             }
//         });
//     } catch (err) {
//         console.error(err);
//         res.status(500).send();
//     }
// });

// router.put("/requests", auth, async (req, res) => {
//     try {
//         Requests.updateOne({ _id: req.body.id }, { status: req.body.status }, (err, user) => {
//             if (err) {
//                 res.status(404).send("Request not found");
//             } else {
//                 res.status(200).send("Status updated");
//             }
//         });
//     } catch (err) {
//         console.error(err);
//         res.status(500).send();
//     }
// });

// router.get("/donations", auth, async (req, res) => {
//     try {
//         const data = await Donations.find({ bankId: req.user }).populate('userId', '-__v -password -requests -donations -stock');
//         res.json(data);
//     } catch (err) {
//         console.error(err);
//         res.status(500).send();
//     }
// });

// router.get("/requests", auth, async (req, res) => {
//     try {
//         const data = await Requests.find({ bankId: req.user }).populate('userId', '-__v -password -requests -donations -stock');
//         res.json(data);
//     } catch (err) {
//         console.error(err);
//         res.status(500).send();
//     }
// });

// router.put("/", auth, async (req, res) => {
//     try {
//         console.log(req.user);
//         BloodBank.updateOne({ _id: req.user }, req.body, (err, user) => {
//             if (err) {
//                 res.status(404).send("BloodBank not found");
//             } else {
//                 res.status(200).send("BloodBank updated");
//             }
//         });
//     } catch (err) {
//         console.error(err);
//         res.status(500).send();
//     }
// });

module.exports = router;