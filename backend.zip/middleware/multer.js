const multer = require("multer")
const path = require("path")

var storage = multer.diskStorage({
    destination: ((req, file, cb) => {
        cb(null, 'uploads/')
    }),
    filename: ((req, file, cb) => {
        let ext = path.extname(file.originalname)
        cb(null, Date.now() + ext)
    })
});

var upload = multer({
    storage: storage,
    fileFilter: ((req, file, callback) => {
        if (file.mimetype === "image/png"
            || file.mimetype === "image/jpg"
            || file.mimetype === "image/jpeg") {
            callback(null, true);
        } else {
            console.log("Only jpg & png files supported...!");
            callback(null, false);
        }
    }),
    limits: {
        fileSize: 1024 * 1024 * 5
    }
});

module.exports = { upload };