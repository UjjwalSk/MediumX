const data = [
	{
		key: 0,
		title: "Title 1 Here",
		content:
			"Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis possimus ullam architecto asperiores obcaecati praesentium!",
	},
	{
		key: 1,
		title: "Title 2 Here",
		content:
			"Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam, fuga est numquam corporis debitis doloribus.",
	},
	{
		key: 2,
		title: "Title 3 Here",
		content:
			"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt ex neque labore iste laborum obcaecati.",
	},
	{
		key: 3,
		title: "Title 4 Here",
		content:
			"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi sint corporis aspernatur, cum corrupti eius.",
	},
	{
		key: 4,
		title: "Title 5 Here",
		content:
			"Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam quaerat deleniti ullam corrupti fugit voluptatum.",
	},
	{
		key: 5,
		title: "Title 6 Here",
		content:
			"Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis possimus ullam architecto asperiores obcaecati praesentium!",
	},
	{
		key: 6,
		title: "Title 7 Here",
		content:
			"Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam, fuga est numquam corporis debitis doloribus.",
	},
	{
		key: 7,
		title: "Title 8 Here",
		content:
			"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt ex neque labore iste laborum obcaecati.",
	},
];

export default data;
