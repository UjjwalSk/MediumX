import React, { useEffect, useState, useContext } from "react";
import { useNavigate, useParams } from "react-router-dom";
import AuthContext from "../context/AuthContext";
import axios from "./Api";

const Edit = (props) => {
	const navigate = useNavigate();
	const [data, setData] = useState({});
	const { getLoggedIn } = useContext(AuthContext);

	// let { id } = useParams([]);

	// useEffect(() => {
	// 	if (localStorage.getItem("user") !== "admin" || isNaN(id)) {
	// 		navigate("404");
	// 	}
	// 	axios.get(`/data/${id}`).then((r) => setData(r.data));
	// }, []);

	const submit = async (e) => {
		e.preventDefault();


		const formData = new FormData();
		formData.append('img', props.user.img);
		formData.append('uname', props.user.uname);
		formData.append('mail', props.user.mail);
		if (props.user.bio != undefined && props.user.bio != null)
			formData.append('bio', props.user.bio);

		await axios.put(`/user/${props.user._id}`, formData, { withCredentials: true });
		await getLoggedIn();
		navigate(`/user/~`)
	};

	return (
		<div className="flex justify-center m-24">
			<div
				href="#"
				className={`flex items-center rounded-lg border-r-4 border-metal flex-row max-w-4xl shadow-xl bg-white-900 ${!props.uname &&
					(props.choice % 2 ? "self-end" : "self-start")
					}`}
			>
				<div>
					<img
						className="uploadedImage rounded-[50%] m-9"
						src={typeof (props.user.img) === 'string' ? `${props.host}/uploads/${props.user.img}` :
							URL.createObjectURL(props.user.img)}
						alt=""
					/>

					<center className="m-9 ml-24">
						<input
							type="file"
							name="file-input"
							id="file-input"
							className="finput"
							accept="image/png,image/jpg"
							onChange={(e) => {
								props.user.img = e.target.files[0];
								setData({ ...data });
							}}
						/>
						<label
							className="flabel"
							for="file-input"
						>
							<svg
								aria-hidden="true"
								focusable="false"
								data-prefix="fas"
								data-icon="upload"
								className="svg-inline--fa fa-upload fa-w-16"
								role="img"
								xmlns="http://www.w3.org/2000/svg"
								viewBox="0 0 512 512"
							>
								<path
									fill="currentColor"
									d="M296 384h-80c-13.3 0-24-10.7-24-24V192h-87.7c-17.8 0-26.7-21.5-14.1-34.1L242.3 5.7c7.5-7.5 19.8-7.5 27.3 0l152.2 152.2c12.6 12.6 3.7 34.1-14.1 34.1H320v168c0 13.3-10.7 24-24 24zm216-8v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h136v8c0 30.9 25.1 56 56 56h80c30.9 0 56-25.1 56-56v-8h136c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z"
								></path>
							</svg>
						</label>
					</center>
				</div>

				<div className="flex flex-col justify-between p-9 text-center">
					<form className="space-y-4" action="" onSubmit={submit}>
						<h1 className="text-3xl font-bold underline decoration-double mb-3">
							User Details
						</h1>
						<input
							className="w-full p-4 text-sm border border-silver rounded"
							type="text"
							placeholder="UserName"
							value={props.user.uname}
							required
							onChange={(e) => {
								props.user.uname = e.target.value;
								setData({ ...data });
							}}
						/>
						<input
							className="w-full p-4 text-sm border border-silver rounded"
							type="email"
							placeholder="Email"
							value={props.user.mail}
							required
							onChange={(e) => {
								props.user.mail = e.target.value;
								setData({ ...data });
							}}
						/>

						<input
							className="w-full p-4 text-sm border border-silver rounded"
							type="text"
							maxLength={66}
							placeholder="Bio..."
							value={props.user.bio ?? props.user.bio}
							onChange={(e) => {
								props.user.bio = e.target.value;
								setData({ ...data });
							}}
						/>
						{/* <input
							className="w-full p-4 text-sm border border-silver rounded"
							type="password"
							placeholder="Password"
							value={props.user.pass}
							required
							onChange={(e) => {
								props.user.pass = e.target.value;
								setData({ ...data });
							}}
						/> */}
						<button
							type="submit"
							className="w-4/12 py-3 mx-2 bg-metal text-white-900 hover:bg-midnight rounded text-sm font-bold"
						>
							Update
						</button>
						<button
							className="w-4/12 py-3 mx-2 bg-red text-white-900 hover:bg-midnight rounded text-sm font-bold"
							onClick={() => navigate(`/user/~`)}
						>
							Cancel
						</button>
					</form>
				</div>
			</div>
		</div>
	);
};

export default Edit;
