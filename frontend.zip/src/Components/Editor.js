import React, { useState, useEffect } from "react";
import ReactQuill from "react-quill";
import { useParams, useNavigate } from "react-router-dom";
import "react-quill/dist/quill.snow.css";
import axios from "./Api";

const Editor = () => {
	const { use, uid, blogID } = useParams();
	const [data, setData] = useState("");
	const [title, setTitle] = useState("");
	const [uname, setUname] = useState("");
	const navigate = useNavigate();

	useEffect(() => {
		if (use == 1) {
			axios.get(`/blog/${blogID}`, { withCredentials: true }).then((r) => {
				setTitle(r.data.title);
				setData(r.data.content);
			}).catch(e => {
				console.log(e);
			})
		}
	}, []);

	const submit = async (e) => {
		e.preventDefault();
		const obj = {
			title: title,
			content: data,
			date: new Date().toLocaleDateString()
		};
		if (use == 0) {
			await axios.post('/blog', obj, { withCredentials: true }).then((r) => { console.log(r) }).catch(e => console.log(e))
		} else if (use == 1) {
			await axios.put(`/blog/${blogID}`, obj, { withCredentials: true }).then((r) => { console.log(r) }).catch(e => console.log(e))
		}
		navigate(`/user/~`);
	};

	return (
		<div className="mx-3 text-center">
			<button
				onClick={submit}
				className="w-4/12 py-3 mx-2 bg-metal text-white-900 hover:bg-midnight rounded text-sm font-bold"
			>
				Save
			</button>
			<button
				className="w-4/12 py-3 mx-2 bg-red text-white-900 hover:bg-midnight rounded text-sm font-bold"
				onClick={() => navigate(`/user/~`)}
			>
				Cancel
			</button>
			<input
				className="block w-7/12 p-4 m-5 text-lg font-bold border border-silver rounded"
				type="text"
				placeholder="Title"
				value={title}
				required
				onChange={(e) => {
					setTitle(e.target.value);
				}}
			/>
			<ReactQuill
				className="m-5 dark:bg-white-900 dark:text-black"
				theme="snow"
				onChange={(e) => setData(e)}
				value={data}
				modules={{
					toolbar: [
						[{ header: "1" }, { header: "2" }, { font: [] }],
						[{ size: [] }],
						["bold", "italic", "underline", "strike", "blockquote"],
						[
							{ list: "ordered" },
							{ list: "bullet" },
							{ indent: "-1" },
							{ indent: "+1" },
						],
						["link", "image", "video"],
						["clean"],
					],
					clipboard: {
						matchVisual: false,
					},
				}}
				formats={[
					"header",
					"font",
					"size",
					"bold",
					"italic",
					"underline",
					"strike",
					"blockquote",
					"list",
					"bullet",
					"indent",
					"link",
					"image",
					"video",
				]}
				bounds={".app"}
				placeholder={"Write something"}
			/>
		</div>
	);
};

export default Editor;
