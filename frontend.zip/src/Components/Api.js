import axios from "axios";

const PORT = 3177
const baseURL = `http://localhost:${PORT}/`;

export default axios.create({ baseURL: baseURL });
