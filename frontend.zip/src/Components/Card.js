import React, { useContext } from "react";
import AuthContext from "../context/AuthContext";
import { Link } from "react-router-dom";

const Card = (props) => {
	const { loggedIn } = useContext(AuthContext);
	return (
		<div
			href="#"
			className={`rounded-lg hover:border-r-8 hover:border-b-8 hover:shadow-metal hover:cursor-wait m-8 border-metal max-w-sm w-[500px] overflow-hidden shadow-2xl bg-white-900`}
		>
			<div className="flex flex-col justify-between p-10 drop-shadow-2xl text-center">
				<Link to={loggedIn?`/blog/${props.obj._id}`:'/account/signup'}>
					<h5 className="mb-2 text-2xl text-left font-bold tracking-tight text-gray-900 drop-shadow-2xl hover:text-metal hover:cursor-pointer">
						{props.obj.title}
					</h5>
				</Link>
				<p
					className="font-normal text-gray-700 text-justify"
					dangerouslySetInnerHTML={{
						__html:
							props.obj.content.length < 150
								? props.obj.content
									.replaceAll('<p>', '')
									.replaceAll('</p>', '')
									.split(" ")
									.splice(0, 15)
									.join(" ") : "" + "....",
					}}
				></p>
			</div>
			<p className="text-right mr-4 mb-4 text-gray-dark hover:text-black hover:cursor-pointer">@<img className="editImage" src={props.img} alt="" />{props.obj.author.uname}</p>
		</div>
	);
};

export default Card;
