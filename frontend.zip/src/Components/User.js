import React, { useEffect, useState, useContext } from "react";
import axios from "./Api";
import Admin from "./Admin";
import CrudTable from "./CrudTable";
import AuthContext from "../context/AuthContext";
import { Link, useParams } from "react-router-dom";

const User = (props) => {
	const [title, setTitle] = useState("");
	const [flag, setFlag] = useState(false);
	const [data, setData] = useState([]);
	const { getLoggedIn, user } = useContext(AuthContext);
	const [view, setView] = useState(props.user);
	const { uname } = useParams();

	useEffect(() => {
		if (uname == "~") {
			getLoggedIn();
			setView(props.user);
		} else {
			axios.get(`/user/view/${uname}`, { withCredentials: true }).then((r) => {
				setView(r.data);
				setFlag(false);
				props.user = r.data;
			}).catch((e) => console.log(e))
		}
	}, [uname]);

	const filter = async (e) => {
		let key = e.target.value.toLowerCase();
		let filterData = user.blogs.filter((x) => {
			return x.title.toLowerCase().indexOf(key) !== -1;
		});
	};

	const deleteData = async (i, j) => {
		axios.delete(`/blog/${i}`, { withCredentials: true }).then((r) => {
			view.blogs.splice(j - 1, 1); getLoggedIn();
		}
		).catch((e) => {
			console.log(e);
		});
	};

	return (
		<div className="flex flex-col content-center items-center justify-center mt-8 mb-20 dark:text-white-900">
			{view.uname === "admin" ? (
				<Admin />
			) : (
				<>
					<div
						className="flex items-center text-center justify-evenly rounded-lg border-r-4 border-metal flex-row w-screen"
					>
						<img
							className="uploadedImage rounded-[50%] w-[220px] drop-shadow-2xl pointer-events-none"
							src={`${props.host}/uploads/${view.img}`}
							alt=""
						/>
						<div>
							Username:{" "}
							<h5 className="mb-2 text-5xl font-bold tracking-tight text-gray-900 drop-shadow-2xl">
								{view.uname}
							</h5>
							{view.bio && <p className="vertical-center text-gray-dark italic break-words">
								© {view.bio}
							</p>}
						</div>
						<div>
							Mail:{" "}
							<h5 className="mb-3 text-lg font-normal text-gray-700">
								{view.mail}
							</h5>
						</div>
						<table cellPadding={15}>
							<tr>
								<td className="">
									<p className="text-4xl font-bold tracking-tight text-gray-900 drop-shadow-2xl">{view.blogs.length}</p>
									<p className="text-md">Stories</p>
								</td>
								<td className="hover:text-decoration hover:underline hover:cursor-pointer" onClick={
									() => {
										setFlag(true);
										setTitle("Followers");
										setData(view.followers);
									}
								}>
									<p className="text-4xl font-bold tracking-tight text-gray-900 drop-shadow-2xl">{view.followers.length}</p>
									<p className="text-md">Followers</p>
								</td>
							</tr>
							<tr>
								<td colSpan={2} className="hover:text-decoration hover:underline hover:cursor-pointer" onClick={
									() => {
										setFlag(true);
										setTitle("Following");
										setData(view.following);
									}
								}>
									<p className="text-4xl font-bold tracking-tight text-gray-900 drop-shadow-2xl">{view.following.length}</p>
									<p className="text-md">Following</p>
								</td>
							</tr>
						</table>
						{
							flag &&
							<>
								<ul className="max-h-[200px] overflow-y-scroll pr-7">
									<li className="float-right hover:cursor-pointer hover:scale-150" onClick={() => setFlag(false)}>
										<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" fill="currentColor" class="bi bi-x" viewBox="0 0 16 16">
											<path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
										</svg>
									</li>
									<li className="text-2xl font-bold my-4">{title}</li>
									{
										data.map((e) => {
											return (<li><Link to={`/user/${e._id}`}>{e.uname}</Link></li>)
										})
									}
								</ul>
							</>
						}
						<div>
							<Link to={`/editor/0/1`}>
								<h1 id="cbtn" className="mx-2 px-9 py-2 font-semibold text-base rounded-full shadow-sm bg-metal text-white-900 hover:drop-shadow-md hover:opacity-80 hover:cursor-pointer">
									Create New
								</h1>
							</Link>
							<br />
							<Link to={`/user/edit`}>
								<h1 className="mx-2 px-9 py-2 font-semibold text-base rounded-full shadow-sm bg-metal text-white-900 hover:drop-shadow-md hover:opacity-80 hover:cursor-pointer">
									Edit Profile
								</h1>
							</Link>
						</div>
					</div>
					<h5 className="my-5 text-3xl font-bold tracking-tight text-gray-900 drop-shadow-2xl">
						My Stories
					</h5>
					<CrudTable
						head={["ID", "Story Title", "Date", "Edit", "Delete"]}
						opts={["title", "date"]}
						data={view.blogs}
						state={uname == "~"}
						filter={() => console.log("appel")}
						myPath={`/editor/1/`}
						delete={deleteData}
					/>
				</>
			)}
		</div>
	);
};

export default User;
