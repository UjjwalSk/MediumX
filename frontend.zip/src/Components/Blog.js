import React, { useState, useEffect, useContext } from "react";
import { useParams, span } from "react-router-dom";
import axios from "../Components/Api";
import AuthContext from "../context/AuthContext";

const Blog = (props) => {
	const { id } = useParams();
	const [data, setData] = useState({});
	const [following, setFollowing] = useState(false);
	const { user, host } = useContext(AuthContext);
	useEffect(() => {
		axios.get("/blog/" + id).then((r) => {
			setData(r.data);
			setFollowing(user.following.includes(r.data.author._id));
			console.log(r.data.author.following.includes(user._id))
			console.log(user.following);
			console.log(r.data.author._id)
		}).catch((e) => console.log(e));
	}, []);

	const foo = () => {
		if (following) {
			axios.post(`/user/unfollow/${data.author._id}`, {}, { withCredentials: true }).then((r) => setFollowing(!following));
		} else {
			axios.post(`/user/follow/${data.author._id}`, {}, { withCredentials: true }).then((r) => setFollowing(!following));
		}
	};

	return (
		<div className="flex justify-center p-9 dark:text-white-900">
			<div className="w-9/12 shadow-2xl p-10 text-justify m-2">
				<h1 className="text-4xl font-bold">
					{data.title}
				</h1><br />
				<span to="/" className="float-right text-center">
				<img
					src={data.author && `${host}/uploads/${data.author.img}`}
					width="220"
					alt=""
					className="uploadedImage ml-5 mb-3 rounded-[50%] shadow-2xl"
				/>
				<p>
					@<b>{data.author && data.author.uname}</b>
				</p>
				<p>
					~ <b>{new Date(data.date).toLocaleDateString()}</b>
				</p>
				{data.author && user._id!==data.author._id && <button className={`ml-3 mb-5 mt-3 px-7 py-1 font-semibold text-sm rounded-full shadow-sm text-white-900 hover:drop-shadow-md hover:opacity-80 ${following ? "bg-gray-dark" : "bg-metal"}`}
					onClick={() => foo()}
				>
					{following ? "Unfollow" : "Follow"}
				</button>}
				</span>
				<p
					dangerouslySetInnerHTML={{
						__html: data.content,
					}}
				></p>
			</div>
		</div>
	);
};

export default Blog;
