const Footer = () => {
	return (
		<>
			<div className="fixed bottom-0 text-xs bg-purple w-full mb-0 text-center text-white-900 py-1 z-50">
				© 2022 | MyWorld | All Rights Reserved
			</div>
		</>
	);
};

export default Footer;
