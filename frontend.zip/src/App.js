import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useContext } from "react";
import Navbar from "./Components/Navbar";
import Home from "./Pages/Home";
import About from "./Pages/About";
import ContactUs from "./Pages/ContactUs";
import NoPage from "./Pages/NoPage";
import Footer from "./Components/Footer";
import Auth from "./Components/Auth";
import User from "./Components/User";
import Edit from "./Components/Edit";
import Editor from "./Components/Editor";
import Blog from "./Components/Blog";
import AuthContext from "./context/AuthContext";
import "./App.css";

export default function App() {

	const { loggedIn, user, host } = useContext(AuthContext);

	return (
		<>
			<BrowserRouter>
				<Routes>
					<Route
						path="/"
						element={<Navbar logIn={loggedIn} user={user} />}
					>
						<Route index element={<Home host={host} />} />
						<Route path="about" element={<About />} />
						<Route path="contact" element={<ContactUs />} />
						{!loggedIn && (
							<Route
								path="account/:handle"
								element={
									<Auth logIn={loggedIn} />
								}
							/>
						)}
						{loggedIn && (
							<>
								<Route path="/user/:uname" element={<User user={user} host={host} />} />
								<Route
									path="/user/edit"
									element={<Edit user={user} host={host} />}
								/>
								{/* path="/user/admin/edit/:id" */}
								<Route
									path="/editor/:use/:blogID"
									element={<Editor />}
								/>
								<Route path="/blog/:id" element={<Blog />} />
							</>
						)}
						<Route path="*" element={<NoPage />} />
					</Route>
				</Routes>
				<Footer></Footer>
			</BrowserRouter>
		</>
	);
}
