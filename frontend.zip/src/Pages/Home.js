import React, { useState, useEffect } from "react";
import axios from "../Components/Api";
import Card from "../Components/Card";
import map from "../assets/map.svg";
import ReactVivus from "react-vivus";
import svg from "../assets/term.svg";
import Typewriter from "typewriter-effect";

const Home = (p) => {
	setTimeout(function () {
		document.getElementById("b1").style.fill = "#4261f1";
		document.getElementById("b2").style.fill = "#4261f1";
		document.getElementById("g1").style.fill = "#40e137";
		document.getElementById("g2").style.fill = "#40e137";
		document.getElementById("bl").style.fill = "#902bf5";
	}, 2000);
	const [data, setData] = useState("");
	useEffect(() => {
		axios.get("/blog/all").then((r) => {
			setData(r.data);
		})
	}, []);

	return (
		<>
			<div className="flex items-center justify-center">
				<ReactVivus
					id="fooo"
					option={{
						file: svg,
						animTimingFunction: "EASEINOUT",
						type: "scenario",
						onReady: console.log,
						duration: 500,
					}}
					style={{ height: "75vh", width: "550px" }}
					callback={console.log}
				/>
				<div className="text-7xl font-bold text-metal text-center leading-[4.7rem] mx-12 mb-10 dark:text-white-400">
					<Typewriter
						onInit={(typewriter) => {
							typewriter
								.typeString("Hi,<br/>Ujjwal Here")
								.pauseFor(500)
								.deleteAll()
								.typeString(
									"Welcome<br/>To<br/>MyWorld<br/>▼"
								)
								.start();
						}}
					/>
				</div>
			</div>
			<hr class="w-96 h-1 mx-auto my-4 bg-metal border-0 rounded md:my-10 dark:bg-gray-700" />
			<div className="flex flex-row justify-center flex-wrap p-12">
				{
					data &&
					data.map((e, i) => {
						if (e)
							return (
								<Card
									key={i}
									obj={e}
									img={`${p.host}/uploads/${e.author.img}`}
									choice={i}
									style={{ zIndex: 2 }}
									raw={{ ...e }}
								/>
							);
					})
					// data.map((e, i) => (
					// <Card
					// 	key={i}
					// 	title={e.title}
					// 	content={e.content}
					// 	choice={i}
					// 	style={{ zIndex: 2 }}
					// />
					// ))
				}
			</div>
			<img
				src={map}
				alt=""
				className="absolute -top-[60px] right-[80px] -z-60 pointer-events-none"
			/>
		</>
	);
};

export default Home;
